# HƯỚNG DẪN CHẠY — dành cho người chấm

Gói gồm hai thư mục:

| Thư mục | Nội dung | Thời gian thử |
|---|---|---|
| `1_Chuong_trinh/` | Phần mềm đầy đủ, có giao diện | khoảng 10 phút |
| `2_Thuat_toan_loi/` | Mọi thuật toán phần mềm dùng, chạy độc lập | khoảng 1 phút |

Mọi dữ liệu mẫu trong gói là **dữ liệu mô phỏng**, không phải dữ liệu học sinh thật.

---

## Bước 0 — Cài Python (làm một lần)

1. Tải **Python 3.11** tại https://www.python.org/downloads/
2. Khi cài, **tick ô "Add python.exe to PATH"**, rồi bấm *Install Now*.
3. Giải nén cả tệp `.zip` này ra một thư mục, ví dụ `C:\ClubMatch_RBDA`.

---

## A. Chạy thử thuật toán lõi (nhanh nhất)

1. Mở thư mục `2_Thuat_toan_loi`.
2. Bấm đúp **`CHAY_VI_DU.bat`**.

Một cửa sổ đen hiện hai ví dụ. **Ví dụ 1** xếp 10 học sinh vào 3 CLB bằng cách xếp chính:

```
HS01 -> ROBOT general
...
So vong: 2
Cap pha vo on dinh: khong co
```

**Cách đọc:**
- Mỗi dòng là một học sinh và CLB em được xếp vào.
- `reserve` nghĩa là em được xếp vào chỗ dành riêng; `general` là chỗ thường.
- Dòng cuối `khong co` nghĩa là kết quả **ổn định**: không có em nào và CLB nào
  cùng muốn đổi sang nhau. Đây là tính chất chính mà thuật toán bảo đảm.

**Ví dụ 2** thử các thuật toán còn lại mà phần mềm dùng: xếp nhiều buổi trong tuần, cách xếp có huy chương,
vòng đổi chỗ, vòng 2 cho em chưa có chỗ, và đo tỉ lệ em được nguyện vọng 1.
Danh sách đầy đủ các thuật toán: `2_Thuat_toan_loi/GIAI_THICH_CAC_TEP.md`.

Có thể mở `vi_du_chay.py` bằng Notepad, đổi nguyện vọng, điểm hoặc số chỗ,
lưu lại rồi chạy lại để xem kết quả thay đổi.

> Trên macOS hoặc Linux: mở Terminal trong thư mục và gõ `python3 vi_du_chay.py`.

---

## B. Chạy phần mềm đầy đủ

### Mở phần mềm
1. Mở thư mục `1_Chuong_trinh`.
2. Bấm đúp **`CHAY_PHAN_MEM.bat`**.
   - **Lần đầu**, máy tự cài thư viện (cần Internet, khoảng 1–3 phút).
   - Các lần sau, phần mềm mở ngay.
3. Cửa sổ phần mềm hiện ra. Nếu máy không mở được cửa sổ riêng, phần mềm tự
   chuyển sang mở bằng trình duyệt Edge hoặc Chrome; mọi chức năng vẫn như cũ.

> Trên macOS hoặc Linux: mở Terminal trong thư mục và gõ
> `pip install -r requirements.txt`, sau đó gõ `python3 main.py`.

### Thử với dữ liệu mẫu (5 bước)
1. Ở thẻ **Xếp CLB**, kéo tệp
   `1_Chuong_trinh/mau_csv/vi_du_day_du/SO_NHAP_CLB_vi_du.xlsx` vào ô nạp tệp.
2. Phần mềm đọc thử và báo: **9 CLB · 3 buổi · 24 học sinh**. Bấm **Nhập sổ**.
3. Mục *Cảnh báo dữ liệu* hiện **3 cảnh báo**: mỗi buổi có nhiều học sinh hơn số chỗ.
   Nghĩa là ở mỗi buổi sẽ có vài em không có chỗ; phần mềm báo trước để người dùng biết.
   Cảnh báo không chặn việc chạy.
4. Bấm **Chạy sắp xếp** rồi xác nhận. Màn hình hiện lần lượt 5 bước: sao lưu →
   kiểm tra dữ liệu → bốc thăm → chạy thuật toán → ghi kết quả.
5. Xem kết quả ở thẻ **Kết quả**, hoặc bấm nút xuất để lấy tệp Excel.

**Kiểm tính tái lập:** chạy lại với cùng dữ liệu và cùng ô `seed` (mặc định 42)
thì luôn ra đúng kết quả như lần trước.

Hướng dẫn chi tiết từng màn hình: `1_Chuong_trinh/HUONG_DAN_SU_DUNG.md`.

---

## Gặp sự cố

| Hiện tượng | Cách xử lý |
|---|---|
| Báo `'python' is not recognized` | Cài lại Python và nhớ tick **Add python.exe to PATH** |
| Lỗi khi cài thư viện lần đầu | Kiểm tra Internet, xoá thư mục `.venv` trong `1_Chuong_trinh`, chạy lại |
| Windows hỏi có cho chạy tệp `.bat` không | Bấm **More info → Run anyway** |
| Muốn làm lại từ đầu với dữ liệu trống | Đóng phần mềm, xoá thư mục `workspaces` trong `1_Chuong_trinh`, mở lại |

Phiên bản đã kiểm: Python 3.11. Các thư viện cần cài được ghi trong `1_Chuong_trinh/requirements.txt`.
