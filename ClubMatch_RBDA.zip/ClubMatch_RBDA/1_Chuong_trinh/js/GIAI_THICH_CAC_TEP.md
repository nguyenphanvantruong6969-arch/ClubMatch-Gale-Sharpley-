# Các tệp vẽ màn hình (thư mục `js/`)

Mỗi tệp lo một phần của màn hình. Khi người dùng bấm nút, tệp gửi yêu cầu cho phần làm việc phía sau
và hiện kết quả trả về. Tệp `_danh_sach.txt` ghi thứ tự nạp các tệp.

| Tệp | Lo phần nào trên màn hình |
|---|---|
| `00_nen.js` | Công cụ nền mà mọi thẻ dùng: hiện thông báo, nút "đang bận", báo lỗi ngay tại ô nhập. |
| `01_khung.js` | Thanh bên trái và việc chuyển giữa các thẻ. |
| `02_van_hanh.js` | Thẻ **Xếp CLB**: nạp Sổ nhập, xem cảnh báo dữ liệu, bấm chạy xếp và xem tiến trình. |
| `03_ket_qua.js` | Thẻ **Chi tiết và xuất tệp**: các bảng chi tiết và nút xuất tệp. |
| `04_nhap_tai_cho.js` | Nhập tại chỗ: học sinh tự chọn CLB muốn thi và xếp thứ tự nguyện vọng ngay trên máy. |
| `05_quan_ly.js` | Thẻ **Quản lý**: danh sách CLB, buổi trong tuần, lịch, số chỗ. |
| `06_cham_diem.js` | Thẻ **Nhập điểm**: giáo viên nhập điểm thi mà không thấy tên học sinh. |
| `075_workspace.js` | Chọn, tạo và đổi không gian làm việc. |
| `07_ngon_ngu.js` | Đổi giữa tiếng Việt và tiếng Anh. |
| `08_khoi_dong.js` | Việc làm lúc mới mở phần mềm: chờ phần phía sau sẵn sàng rồi hiện màn hình. |
| `09_the_xem.js` | Thẻ **Kết quả**, chỉ xem: cho Ban giám hiệu, người phụ trách CLB và giáo viên chủ nhiệm. |
| `10_theo_doi.js` | Theo dõi sau khi xếp: điểm danh, khiếu nại, vòng 2, phản hồi của học sinh. |
| `11_chuan_bi.js`, `12_chuan_bi_nap.js`, `13_chuan_bi_bo.js` | Thẻ **Chuẩn bị đợt**: năm bước làm biểu mẫu trực tuyến và nạp kết quả về. |
| `14_giai_trinh.js` | Tra cứu một học sinh và xem lời giải thích kết quả của em đó. |
| `15_tieu_chi.js` | Hiện luật xếp đang dùng bằng lời thường. |
| `16_tai_khoan.js` | Màn hình đăng nhập và quản lý tài khoản. |
| `17_viec_tiep_theo.js` | Thanh "Việc tiếp theo": luôn gợi ý đúng một việc nên làm kế tiếp. |
| `18_cai_dat.js` | Trang **Cài đặt**: chọn cách học sinh bày tỏ mong muốn. |
| `19_muc_tieu.js` | Câu hỏi thứ hai ở Cài đặt: khi CLB đông người, trường ưu tiên điều gì. |
| `19_ux1b_gv.js` | Xem và xuất kết quả theo lớp, và báo cáo tổng hợp cho Ban giám hiệu. |
