# Mỗi tệp trong thư mục này làm gì

Thư mục này là **phần mềm đầy đủ**. Phần mềm gồm ba phần:
- **Phần nhìn thấy:** màn hình và các nút bấm, nằm trong thư mục `js/` và các tệp `.html`, `.css`.
- **Phần làm việc phía sau:** các tệp `.py`, nhận yêu cầu từ màn hình rồi tính toán, lưu và xuất kết quả.
- **Bộ óc xếp chỗ:** tệp `rbda_priority_pipeline.py`, giống hệt tệp trong thư mục `2_Thuat_toan_loi`.

Thư mục con có tài liệu giải thích riêng:
- `js/GIAI_THICH_CAC_TEP.md`: các tệp vẽ màn hình.
- `mau_forms_thi_clb/GIAI_THICH_CAC_TEP.md`: công cụ làm biểu mẫu đăng ký trực tuyến.

---

## 1. Mở phần mềm

| Tệp | Làm gì |
|---|---|
| `CHAY_PHAN_MEM.bat` | Bấm đúp để mở phần mềm. Lần đầu, tệp tự cài những gì còn thiếu. |
| `main.py` | Điểm khởi động: mở cửa sổ phần mềm và nối màn hình với phần làm việc phía sau. |
| `browser_host.py` | Đường dự phòng: nếu cửa sổ riêng không mở được thì mở phần mềm bằng trình duyệt Edge hoặc Chrome. |
| `chan_doan.py` | Ghi lại lý do khi phần mềm không mở được, để người sửa lỗi đọc. |
| `recovery.py`, `recovery.html`, `recovery.js` | Màn hình "cứu hộ": chỉ hiện khi dữ liệu bị hỏng, cho phép lấy lại bản sao lưu. |
| `QUEN_MAT_KHAU.bat` | Dùng khi quản trị viên quên mật khẩu: xoá tài khoản để đặt lại. |

## 2. Bộ óc xếp chỗ

| Tệp | Làm gì |
|---|---|
| `rbda_priority_pipeline.py` | Cách xếp học sinh vào CLB, bốc thăm công bằng, kiểm kết quả ổn định, và lưu dữ liệu. Giải thích kỹ hơn ở `2_Thuat_toan_loi/GIAI_THICH_CAC_TEP.md`. |
| `fa_daa.py` | Cách xếp thứ hai, **tắt sẵn**: học sinh gắn "huy chương" vàng, bạc, đồng cho các CLB để nói rõ mình muốn CLB nào nhiều hơn. |
| `fa_vong_doi_cho.py` | Sau khi xếp, tìm những nhóm em có thể đổi chỗ cho nhau mà ai cũng vui hơn. Chỉ để đo, không sửa kết quả. |
| `muc_tieu.py`, `muc_tieu_do.py` | Ba lựa chọn mục tiêu của trường khi CLB đông người, ví dụ ưu tiên điểm thi hay dành chỗ cho một nhóm. Đo xem mục tiêu đó có đạt hay không. |
| `tieu_chi.py` | Viết lại luật xếp đang dùng bằng lời thường để người dùng đọc hiểu. |

## 3. Phần làm việc phía sau (nhận lệnh từ các nút bấm)

| Tệp | Làm gì |
|---|---|
| `api.py` | "Tổng đài": nhận mọi yêu cầu từ màn hình. Chạy trọn quy trình xếp: sao lưu → kiểm dữ liệu → bốc thăm → xếp → kiểm lại → lưu. Gặp lỗi thì quay về như cũ. |
| `api_chung.py` | Những công cụ nhỏ mà các tệp `api_...` cùng dùng. |
| `api_nhap.py` | Đọc tệp Excel hoặc CSV mà trường đưa vào. Kiểm lỗi trước khi lưu. |
| `api_cham_diem.py` | Cho giáo viên nhập điểm thi mà không thấy tên học sinh (chấm mù). |
| `api_quan_ly.py` | Thêm, sửa, xoá CLB và học sinh. Nhập nguyện vọng tại chỗ. Báo trước các thiếu sót của dữ liệu. |
| `api_bao_cao.py` | Dựng các bảng xem kết quả: CLB nào đầy, bao nhiêu em được nguyện vọng 1, thời khoá biểu. |
| `api_xuat.py` | Xuất kết quả ra tệp Excel, CSV hoặc PDF. |
| `api_sau_xep.py` | Việc sau khi đã xếp: điểm danh, nhường chỗ trống, mời em trong danh sách chờ, nhận khiếu nại. |
| `api_workspace.py` | Quản lý nhiều "không gian làm việc", ví dụ mỗi trường hoặc mỗi năm học một bộ dữ liệu riêng. |
| `api_tieu_chi.py`, `api_muc_tieu.py` | Đưa luật xếp và mục tiêu của trường lên màn hình Cài đặt. |
| `api_tai_khoan.py`, `api_nhat_ky.py` | Đăng nhập, và xem nhật ký ai đã làm gì. |
| `api_forms.py`, `api_forms_bo.py`, `api_forms_nap.py` | Thẻ "Chuẩn bị đợt": tạo biểu mẫu đăng ký trực tuyến và nạp kết quả từ biểu mẫu vào phần mềm. |

## 4. Nhập, xuất và in

| Tệp | Làm gì |
|---|---|
| `so_nhap.py` | Đọc và tạo "Sổ nhập CLB": **một** tệp Excel chứa cả danh sách CLB lẫn nguyện vọng và điểm của học sinh. |
| `so_excel.py` | Trình bày tệp Excel kết quả cho dễ đọc và dễ in. |
| `xuat_pdf.py` | Công cụ tạo tệp PDF có tiếng Việt. |
| `danh_sach_pdf.py` | In danh sách thành viên theo CLB hoặc theo lớp. |
| `phieu_giai_trinh.py` | In cho mỗi em một phiếu giải thích vì sao em được xếp vào CLB đó. |
| `bao_cao_tong_hop.py` | Báo cáo tổng hợp cho Ban giám hiệu: chỉ có số liệu chung, không có tên hay điểm của em nào. |
| `fa_bien_ban.py` | In biên bản bốc thăm để người chứng kiến ký. |
| `forms_dot.py` | Chỉ chỗ cất các tệp của một đợt đăng ký trực tuyến. |

## 5. Giải thích kết quả cho học sinh

| Tệp | Làm gì |
|---|---|
| `giai_trinh.py` | Dựng lại lý do vì sao một em được, hoặc không được, vào từng CLB em đã chọn. |
| `fa_ly_do.py` | Kho câu giải thích viết sẵn, chỉ nói về chính em đó, không lộ thông tin của bạn khác. |
| `ma_tra_cuu.py` | Tạo mã tra cứu riêng để mỗi em tự xem kết quả và lời giải thích của mình. |
| `fa_sau_xep.py` | Ghi lại mọi lần đổi chỗ sau khi công bố. Chỉ ghi thêm, không bao giờ xoá kết quả gốc. |

## 6. Tài khoản, an toàn, ngôn ngữ

| Tệp | Làm gì |
|---|---|
| `tai_khoan.py` | Tài khoản quản trị và giáo viên. Mật khẩu được mã hoá, không lưu nguyên chữ. |
| `phan_quyen.py` | "Người gác cửa": giáo viên chỉ được xem và nhập điểm; quản trị viên mới được sửa dữ liệu. |
| `nhat_ky.py` | Sổ ghi ai làm gì, lúc nào. Không ai sửa hay xoá được sổ này. |
| `workspace.py`, `cau_hinh_ws.py` | Mỗi không gian làm việc có thư mục, từ ngữ và luật xếp riêng. |
| `nhan_ws.py` | Đổi từ ngữ trên màn hình, ví dụ "Học sinh/CLB" thành "Nhân viên/Dự án", để dùng cho nơi khác ngoài trường học. |
| `lop_hoc_sinh.py` | Viết lại tên lớp cho thống nhất. |
| `i18n_errors.py`, `i18n_loi.js` | Kho câu báo lỗi bằng tiếng Việt và tiếng Anh. Tệp `.js` được sinh tự động từ tệp `.py`. |
| `tao_i18n_js.py` | Công cụ cho người lập trình: sinh lại `i18n_loi.js` sau khi sửa câu báo lỗi. |

## 7. Màn hình

| Tệp | Làm gì |
|---|---|
| `index.html` | Khung của màn hình chính. |
| `style.css` | Màu sắc, cỡ chữ, bố cục. |
| `i18n.js` | Mọi chữ trên màn hình bằng hai thứ tiếng. |
| `chung.js` | Phần dùng chung cho màn hình chính và màn hình cứu hộ. |
| `js/` | Các tệp vẽ từng thẻ trên màn hình (xem `js/GIAI_THICH_CAC_TEP.md`). |
| `assets/fonts/`, `logo.*` | Phông chữ tiếng Việt và biểu tượng của phần mềm. |

## 8. Dữ liệu mẫu và đóng gói

| Tệp / thư mục | Làm gì |
|---|---|
| `mau_csv/` | Tệp mẫu để thử: Sổ nhập trống và hai bộ ví dụ mô phỏng. `tao_so_nhap.py` và `vi_du_day_du/tao_bo_mau.py` sinh lại các tệp mẫu này. |
| `mau_forms_thi_clb/` | Công cụ làm biểu mẫu đăng ký trên Microsoft Forms và Google Forms. |
| `requirements.txt` | Danh sách thư viện cần cài để chạy. |
| `requirements-build.txt`, `kiosk.spec`, `build_windows.bat`, `PhanBoCauLacBo.exe.config` | Đóng gói phần mềm thành tệp `.exe` cho Windows. |
| `pyproject.toml` | Cài đặt cho công cụ kiểm mã. |
| `README.md`, `HUONG_DAN_CAI_DAT.md`, `HUONG_DAN_SU_DUNG.md` | Giới thiệu, cách cài đặt, và cách dùng từng màn hình. |
