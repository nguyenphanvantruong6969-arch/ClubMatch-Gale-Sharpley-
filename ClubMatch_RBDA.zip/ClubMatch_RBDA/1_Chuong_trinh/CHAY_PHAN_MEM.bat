@echo off
cd /d "%~dp0"
set PY=py -3
where py >nul 2>nul || set PY=python
if not exist ".venv\Scripts\python.exe" (
  echo [1/2] Dang tao moi truong va cai thu vien lan dau (can Internet, 1-3 phut)...
  %PY% -m venv .venv || goto loi
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto loi
)
echo [2/2] Dang mo phan mem...
".venv\Scripts\python.exe" main.py
goto :eof
:loi
echo.
echo LOI: chua cai duoc. Kiem tra da cai Python 3.11 (tick "Add python.exe to PATH") va co Internet.
pause
