# Công cụ làm biểu mẫu đăng ký (thư mục `mau_forms_thi_clb/`)

Thư mục này giúp trường cho học sinh **đăng ký CLB và làm bài thi trên mạng**, bằng Microsoft Forms hoặc
Google Forms, rồi đưa kết quả vào phần mềm. Phần mềm vẫn chạy bình thường nếu không dùng các công cụ này.

## Tệp dữ liệu

| Tệp | Là gì |
|---|---|
| `de_thi.json` | Đề thi mẫu của các CLB, gồm câu hỏi và đáp án. Mọi công cụ bên dưới đều đọc từ tệp này. |
| `MAU_DE_THI.xlsx` | Tệp Excel mẫu để giáo viên soạn đề thi. |
| `MAU_XUAT_TU_FORMS.xlsx` | Ví dụ tệp mà Microsoft Forms xuất ra, dữ liệu giả. |
| `MAP_NHAP_FORMS_*.json` | Bảng ghép cột: cột nào trong tệp của Forms ứng với thông tin nào trong phần mềm. |
| `README.md` | Ghi chú cho người lập trình. |

## Công cụ phần mềm gọi tới

| Tệp | Làm gì |
|---|---|
| `bieu_mau.py` | Phần chung: từ đề thi dựng ra câu hỏi, đáp án và tên cột. |
| `so_de_thi.py` | Đọc tệp Excel đề thi mà giáo viên soạn. |
| `tao_mau_forms.py` | Tạo trọn bộ biểu mẫu cho Microsoft Forms. |
| `chuyen_phieu_clb.py` | Đọc phiếu thiết lập CLB mà các CLB đã điền, rồi tự phân loại CLB. |
| `chuyen_forms_sang_phan_mem.py` | Đổi tệp kết quả của Forms thành Sổ nhập CLB, đồng thời chấm lại bài thi theo đáp án gốc. |
| `phan_tich_cau_hoi.py` | Xem câu hỏi nào quá dễ hay quá khó, và cân điểm giữa các đề khác nhau. |
| `danh_sach_chua_dang_ky.py` | Lập danh sách học sinh chưa đăng ký, theo từng lớp, gửi giáo viên chủ nhiệm. |
| `doi_chieu_lists.py` | So hai lần xuất danh sách để biết em nào mới đăng ký, em nào đã rút. |
| `ghep_ket_qua_email.py` | Ghép email vào kết quả để gửi cho từng em. Chỉ chạy trên máy của bộ phận tin học. |
| `tao_bo_dung_t4m.py` và thư mục `bo_dung_t4m/` | Tạo sẵn bộ tệp để bộ phận tin học dựng hệ thống đăng ký trên Microsoft 365 (SharePoint, Power Apps, Power Automate). |

## Công cụ dùng riêng, phần mềm không gọi tới

| Tệp | Làm gì |
|---|---|
| `tao_google_forms.py` | Tạo đoạn mã dựng biểu mẫu trên Google Forms. |
| `tao_nhap_forms_6_phan.py`, `tao_word_6_phan.py` | Tạo tệp Word để nhập biểu mẫu 6 phần vào Forms, và tệp Word giải thích biểu mẫu đó. |
| `tao_huong_dan_google.py`, `tao_huong_dan_toan_bo.py` | Tạo tệp Word hướng dẫn từng bước cho giáo viên. |
| `so_sanh_suc_chua.py` | So hai Sổ nhập: không cho giảm số chỗ hay đổi loại CLB sau khi đã chốt. |
| `dong_goi_skill.py` | Đóng gói hai công cụ trợ lý AI của dự án thành tệp `.zip`. |
