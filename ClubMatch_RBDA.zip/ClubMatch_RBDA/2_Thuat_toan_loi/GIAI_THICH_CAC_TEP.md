# Mỗi tệp trong thư mục này làm gì

Thư mục này chứa **mọi phần "bộ óc"** mà phần mềm dùng để quyết định em nào vào câu lạc bộ (CLB) nào,
cùng các phép đo và giải thích kết quả. Không có màn hình, không có nút bấm.
Các tệp giống hệt tệp cùng tên trong `1_Chuong_trinh`.

## Cách xếp chỗ

| Tệp | Làm gì (nói đơn giản) |
|---|---|
| `rbda_priority_pipeline.py` | **Cách xếp chính, đang bật sẵn.** Mỗi em "nộp đơn" vào CLB em thích nhất. CLB tạm giữ những em nó ưu tiên nhất, trong giới hạn số chỗ, và trả lại các em còn lại. Em bị trả lại thì nộp tiếp vào CLB em thích kế tiếp, cho tới khi không còn ai nộp. Tệp này còn: xếp thứ tự ưu tiên trong CLB (em đã thi xét điểm trước, rồi tới số bốc thăm); giữ chỗ dành riêng cho một nhóm; xét "điểm quyết tâm" (mỗi em chia 100 điểm cho các CLB); bốc thăm công bằng và lặp lại đúng như cũ; xếp riêng từng buổi trong tuần; kiểm lại để bảo đảm không có em và CLB nào cùng muốn đổi sang nhau. Tệp cũng có phần lưu và đọc dữ liệu cho phần mềm đầy đủ. |
| `fa_daa.py` | **Cách xếp thứ hai, tắt sẵn, trường bật trong Cài đặt.** Học sinh gắn huy chương vàng, bạc, đồng cho CLB mình thích. Có ba loại CLB: *Tự do* nhận mọi em, *Giới hạn* xét huy chương, *Tuyển chọn* xét điểm thi phải đạt điểm sàn. Em nào chưa có chỗ được đưa vào CLB Tự do ít người nhất. Bên trong vẫn dùng cách xếp chính ở trên. |
| `so_nhap.py` | Định nghĩa ba loại CLB và luật kiểm dữ liệu mà `fa_daa.py` cần. Tệp này cũng đọc và ghi Sổ nhập Excel; riêng phần Excel mới cần cài thêm `openpyxl`. |

## Sau khi xếp

| Tệp | Làm gì |
|---|---|
| `fa_sau_xep.py` | **Vòng 2:** các em chưa có chỗ, lần lượt theo số bốc thăm, chọn CLB còn chỗ trống. **Danh sách chờ:** khi có em rút, mời em kế tiếp. Mọi lần đổi chỗ chỉ được ghi thêm, kết quả gốc không bị xoá. |
| `fa_vong_doi_cho.py` | Tìm những nhóm em có thể đổi chỗ vòng tròn cho nhau mà ai cũng vui hơn. **Chỉ để đo**, không sửa kết quả, và luôn ghi nhãn "không bảo đảm ổn định". |

## Đo và giải thích

| Tệp | Làm gì |
|---|---|
| `muc_tieu.py` | Ba mục tiêu trường có thể chọn khi CLB đông người. Mỗi mục tiêu đặt sẵn một bộ luật xếp. |
| `muc_tieu_do.py` | Đo kết quả: bao nhiêu phần trăm em được nguyện vọng 1, bao nhiêu em chưa có chỗ, một nhóm có được đối xử công bằng không. |
| `giai_trinh.py` | Chạy lại đúng lần xếp đó để tìm lý do vì sao một em được, hoặc không được, vào từng CLB em chọn. |
| `fa_ly_do.py` | Kho câu giải thích viết sẵn, chỉ nói về chính em đó. |
| `phan_tich_cau_hoi.py` | Với bài thi đầu vào: chia đề A, B, C cho từng em, tìm câu quá dễ hay quá khó, và cân điểm giữa các đề để không em nào thiệt vì đề khó hơn. Riêng phần ghi Excel cần `openpyxl`. |

## Tệp phụ

| Tệp | Làm gì |
|---|---|
| `lop_hoc_sinh.py` | Viết lại tên lớp cho thống nhất, ví dụ "10a1" và "Lớp 10A1" thành một tên. |
| `i18n_errors.py` | Kho câu thông báo lỗi bằng tiếng Việt và tiếng Anh. |
| `nhan_ws.py` | Điền đúng từ ngữ vào câu thông báo, ví dụ "học sinh" hay "nhân viên". |

## Ví dụ để thử

| Tệp | Làm gì |
|---|---|
| `vi_du_chay.py` | Xếp 10 học sinh vào 3 CLB bằng cách xếp chính, rồi kiểm tính ổn định. |
| `vi_du_thuat_toan_khac.py` | Thử các thuật toán còn lại: xếp nhiều buổi, cách xếp huy chương, vòng đổi chỗ, vòng 2, đo mục tiêu. |
| `CHAY_VI_DU.bat` | Bấm đúp để chạy cả hai ví dụ trên Windows. |
| `README.md` | Ghi chú ngắn cho người lập trình. |

## Những gì KHÔNG có ở đây (vì không phải thuật toán)

Màn hình, đăng nhập, xuất Excel và PDF, và công cụ làm biểu mẫu trực tuyến. Các phần này nằm trong `1_Chuong_trinh`.
