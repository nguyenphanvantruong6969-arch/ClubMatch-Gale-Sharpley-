# Mỗi tệp trong thư mục này làm gì

Thư mục này chỉ chứa **phần "bộ óc"** của phần mềm: cách quyết định em nào vào câu lạc bộ (CLB) nào.
Không có màn hình, không có nút bấm.

| Tệp | Làm gì (nói đơn giản) |
|---|---|
| `rbda_priority_pipeline.py` | **Tệp quan trọng nhất.** Chứa cách xếp chỗ. Mỗi em lần lượt "nộp đơn" vào CLB em thích nhất. Mỗi CLB tạm giữ những em nó ưu tiên nhất, trong giới hạn số chỗ, và trả lại các em còn lại. Em bị trả lại thì nộp tiếp vào CLB em thích kế tiếp. Lặp lại cho tới khi không còn ai nộp nữa. Tệp này cũng làm thêm bốn việc: **(1)** xếp thứ tự ưu tiên trong từng CLB (em đã thi thì xét điểm trước, sau đó tới số bốc thăm); **(2)** giữ một số chỗ dành riêng cho một nhóm học sinh nếu trường muốn; **(3)** bốc thăm công bằng, ai cũng có một số riêng và cùng một "hạt giống" thì luôn ra cùng kết quả; **(4)** kiểm lại kết quả, bảo đảm không có em và CLB nào cùng muốn đổi sang nhau. Tệp cũng có phần lưu và đọc dữ liệu cho phần mềm đầy đủ dùng. |
| `lop_hoc_sinh.py` | Viết lại tên lớp cho thống nhất, ví dụ "10a1", "10 A1" và "Lớp 10A1" đều thành một tên. |
| `i18n_errors.py` | Kho câu thông báo lỗi bằng hai thứ tiếng (Việt, Anh), để báo khi dữ liệu nhập vào bị sai. |
| `nhan_ws.py` | Điền đúng từ ngữ vào câu thông báo, ví dụ "học sinh" hay "nhân viên", "CLB" hay "dự án", tuỳ nơi dùng phần mềm. |
| `vi_du_chay.py` | **Ví dụ để thử.** Xếp 10 học sinh mô phỏng vào 3 CLB và in kết quả ra màn hình. |
| `CHAY_VI_DU.bat` | Bấm đúp để chạy ví dụ trên Windows. |
| `README.md` | Ghi chú ngắn cho người lập trình. |
