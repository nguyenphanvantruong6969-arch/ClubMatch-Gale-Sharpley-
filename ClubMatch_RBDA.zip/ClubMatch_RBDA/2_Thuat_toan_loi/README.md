# Lõi thuật toán (Gale–Shapley / RB-DA và các thuật toán đi kèm)

Chỉ cần Python 3.11. Không cần thư viện ngoài, trừ hai hàm ghi Excel (`so_nhap`, `phan_tich_cau_hoi`) cần `openpyxl`.

- `python vi_du_chay.py`: RB-DA một buổi, kèm `verify_stability`.
- `python vi_du_thuat_toan_khac.py`: `run_rbda_nhieu_buoi`, `fa_daa.chay_fa_daa`, `fa_vong_doi_cho.chay_chu_trinh`, `fa_sau_xep.chay_vong_2`, `muc_tieu_do`.

Hàm chính: `compute_club_priority`, `club_choice_function`, `run_rbda`, `run_rbda_nhieu_buoi`, `verify_stability`,
`generate_stb_lottery`, `chen_stb_cho_hoc_sinh_moi` (rbda_priority_pipeline) · `chay_fa_daa`, `ly_do_ket_qua` (fa_daa) ·
`tim_chu_trinh`, `chay_chu_trinh` (fa_vong_doi_cho) · `chay_vong_2`, `hang_cho` (fa_sau_xep) ·
`giai_trinh_mot_hoc_sinh` (giai_trinh) · `so_sanh_bien_the`, `diem_dieu_chinh` (phan_tich_cau_hoi).
Mọi tệp giống hệt từng byte với bản trong `1_Chuong_trinh`.
