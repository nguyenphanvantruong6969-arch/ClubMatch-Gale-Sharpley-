# Lõi thuật toán RB-DA (Gale–Shapley + dự trữ mềm + STB)

Chỉ cần Python 3.11, không cần thư viện ngoài.

| Tệp | Vai trò |
|---|---|
| `rbda_priority_pipeline.py` | Toàn bộ thuật toán: `compute_club_priority`, `club_choice_function`, `run_rbda`, `run_rbda_nhieu_buoi`, `verify_stability`, `generate_stb_lottery`, `chen_stb_cho_hoc_sinh_moi`, `default_reserve_eligible_fn` (kèm schema/I-O SQLite) |
| `lop_hoc_sinh.py` | `chuan_hoa_lop` — chuẩn hoá tên lớp (được lõi nhập) |
| `i18n_errors.py`, `nhan_ws.py` | Mã lỗi/thông báo dùng khi kiểm dữ liệu (lõi nhập muộn trong một số hàm) |
| `vi_du_chay.py` | Ví dụ nhỏ trên dữ liệu MÔ PHỎNG: `python vi_du_chay.py` |
