"""Ví dụ tối thiểu: chạy RB-DA trên dữ liệu MÔ PHỎNG nhỏ và kiểm ổn định.
Chạy: python vi_du_chay.py   (chỉ cần Python 3.11, không cần thư viện ngoài)
"""
from rbda_priority_pipeline import (
    default_reserve_eligible_fn, generate_stb_lottery, run_rbda, verify_stability,
)

students = {f"HS{i:02d}": {"reserve_group": "nu" if i % 3 == 0 else None} for i in range(1, 11)}
clubs = {
    "ROBOT": {"capacity": 3, "reserve_capacity": 1, "reserve_group": "nu"},
    "NHAC":  {"capacity": 4, "reserve_capacity": 0},
    "BONG":  {"capacity": 3, "reserve_capacity": 0},
}
# Tier 1: em đã thi CLB ROBOT có điểm; còn lại là Tier 2 (chỉ xét bốc thăm STB)
tested_scores = {"ROBOT": {"HS01": 8.5, "HS02": 7.0, "HS03": 9.0, "HS04": 6.5}}
applicants = {"ROBOT": ["HS01", "HS02", "HS03", "HS04", "HS06", "HS09"],
              "NHAC": list(students), "BONG": list(students)}
preferences = {
    "HS01": ["ROBOT", "NHAC"], "HS02": ["ROBOT", "BONG"], "HS03": ["ROBOT"],
    "HS04": ["ROBOT", "NHAC"], "HS05": ["NHAC", "BONG"], "HS06": ["ROBOT", "BONG"],
    "HS07": ["BONG", "NHAC"], "HS08": ["NHAC"], "HS09": ["ROBOT", "NHAC"], "HS10": ["BONG"],
}
stb = generate_stb_lottery(sorted(students), seed=2026)
for sid in students:
    students[sid]["stb"] = stb[sid]

elig = default_reserve_eligible_fn(students, clubs)
kq = run_rbda(students, clubs, tested_scores, applicants, preferences, stb, elig)
for sid in sorted(kq.assignment):
    print(sid, "->", kq.assignment[sid], kq.matched_tier.get(sid, ""))
print("So vong:", kq.rounds_run)
print("Cap pha vo on dinh:", verify_stability(kq, clubs, preferences, elig) or "khong co")
