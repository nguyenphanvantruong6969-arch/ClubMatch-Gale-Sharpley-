@echo off
cd /d "%~dp0"
set PY=py -3
where py >nul 2>nul || set PY=python
echo ===== VI DU 1: cach xep chinh =====
%PY% vi_du_chay.py
echo.
echo ===== VI DU 2: cac thuat toan con lai =====
%PY% vi_du_thuat_toan_khac.py
echo.
pause
