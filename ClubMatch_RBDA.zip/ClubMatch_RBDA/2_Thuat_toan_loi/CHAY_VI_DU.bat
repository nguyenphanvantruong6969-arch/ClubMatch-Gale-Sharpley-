@echo off
cd /d "%~dp0"
set PY=py -3
where py >nul 2>nul || set PY=python
%PY% vi_du_chay.py
echo.
pause
