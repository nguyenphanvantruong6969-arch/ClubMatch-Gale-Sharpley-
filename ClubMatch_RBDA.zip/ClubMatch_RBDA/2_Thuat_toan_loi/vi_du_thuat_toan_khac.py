"""Ví dụ cho các thuật toán còn lại mà phần mềm dùng. Dữ liệu MÔ PHỎNG.
Chạy: python vi_du_thuat_toan_khac.py   (chỉ cần Python 3.11)
"""
import fa_daa
import fa_sau_xep
import fa_vong_doi_cho
import muc_tieu_do
import rbda_priority_pipeline as rp

hs = [f"HS{i:02d}" for i in range(1, 9)]
stb = rp.generate_stb_lottery(hs, seed=7)
students = {s: {"stb": stb[s], "reserve_group": None} for s in hs}

# 1) Xếp nhiều buổi: mỗi buổi chạy RB-DA riêng --------------------------------------------
clubs = {"CO_VUA": {"capacity": 2, "reserve_capacity": 0, "buoi": "thu_2"},
         "VE":     {"capacity": 2, "reserve_capacity": 0, "buoi": "thu_2"},
         "BONG":   {"capacity": 3, "reserve_capacity": 0, "buoi": "thu_4"},
         "HAT":    {"capacity": 3, "reserve_capacity": 0, "buoi": "thu_4"}}
prefs = {s: (["CO_VUA", "VE", "BONG", "HAT"] if i % 2 else ["VE", "CO_VUA", "HAT", "BONG"])
         for i, s in enumerate(hs)}
scores = {"CO_VUA": {"HS01": 9, "HS02": 6, "HS03": 8}}
app = rp.hop_ung_vien({"CO_VUA": ["HS01", "HS02", "HS03"]}, prefs)
elig = rp.default_reserve_eligible_fn(students, clubs)
kq = rp.run_rbda_nhieu_buoi(students, clubs, scores, app, prefs, stb, elig, seed=7)
print("1) XEP NHIEU BUOI (RB-DA tung buoi)")
for s in hs:
    print("  ", s, kq.assignment[s])

# 2) FA-DAA: cách xếp có huy chương (vàng 60, bạc 30, đồng 10) -----------------------------
fa_clb = {"CO_VUA": {"loai": "TUYEN_CHON", "diem_san": 5}, "VE": {"loai": "GIOI_HAN"},
          "BONG": {"loai": "GIOI_HAN"}, "HAT": {"loai": "TU_DO"}}
huy = {s: ({"CO_VUA": 60, "VE": 30, "BONG": 10} if i % 2 else {"VE": 60, "CO_VUA": 30, "BONG": 10})
       for i, s in enumerate(hs)}
fa = fa_daa.chay_fa_daa(students, clubs, scores, app, prefs, stb, fa_clb, [], huy, seed=7)
print("\n2) FA-DAA (huy chuong, CLB Tu do nhan moi em)")
for s in hs:
    print("  ", s, fa.ket_qua.assignment[s])

# 3) Vòng đổi chỗ (chỉ đo, không sửa kết quả) ------------------------------------------------
asg = {"a": "X", "b": "Y"}
p2 = {"a": ["Y", "X"], "b": ["X", "Y"]}
khoa = {"X": {"a": 0, "b": 0}, "Y": {"a": 0, "b": 0}}
moi, ct = fa_vong_doi_cho.chay_chu_trinh(asg, p2, khoa)
print("\n3) VONG DOI CHO:", asg, "->", moi, "|", fa_vong_doi_cho.NHAN_KHONG_BAO_DAM)

# 4) Vòng 2 (dữ liệu giả định riêng): em chưa có chỗ lần lượt chọn CLB còn chỗ, theo số bốc thăm
ds = fa_sau_xep.chay_vong_2(["HS05", "HS02", "HS07"], {"HS05": ["VE"], "HS02": ["VE", "CO_VUA"],
                            "HS07": ["VE"]}, {"VE": 1, "CO_VUA": 1})
print("\n4) VONG 2:", ds)

# 5) Đo mục tiêu: % được nguyện vọng 1 -----------------------------------------------------
do = {(s, b): (c, (prefs[s].index(c) + 1) if c else None)
      for s in hs for b, c in kq.assignment[s].items()}
print("\n5) DO MUC TIEU: % (em, buoi) duoc nguyen vong 1 =", muc_tieu_do.pct_nguyen_vong_1(do))
