# ClubMatch RB-DA — gói mã nguồn

- `1_Chuong_trinh/` — mã nguồn đầy đủ để chạy phần mềm kiosk (backend Python + giao diện HTML/JS + phông + mẫu nhập).
  Chạy: `pip install -r requirements.txt` rồi `python main.py` (hoặc `python browser_host.py` để mở bằng trình duyệt).
  Đóng gói .exe trên Windows: `build_windows.bat`. Xem `HUONG_DAN_CAI_DAT.md`.
- `2_Thuat_toan_loi/` — chỉ phần thuật toán cốt lõi, chạy độc lập: `python vi_du_chay.py`.

Không gồm: tests, tài liệu kế hoạch (`docs/`), dữ liệu mô phỏng (`du_lieu_test/`), tệp trình bày/báo cáo.
Mọi số liệu trong ví dụ là dữ liệu MÔ PHỎNG.
