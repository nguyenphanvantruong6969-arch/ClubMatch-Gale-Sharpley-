# ClubMatch RB-DA — gói mã nguồn

**→ Cách chạy cho người chấm: xem `HUONG_DAN_CHAY.md`.**

- `1_Chuong_trinh/` — mã nguồn đầy đủ để chạy phần mềm kiosk (backend Python + giao diện HTML/JS + phông + mẫu nhập).
  Chạy: `pip install -r requirements.txt` rồi `python main.py`.
  Đóng gói .exe trên Windows: `build_windows.bat`. Xem `HUONG_DAN_CAI_DAT.md`.
- `2_Thuat_toan_loi/` — chỉ phần thuật toán cốt lõi, chạy độc lập: `python vi_du_chay.py`.

Mỗi thư mục có `GIAI_THICH_CAC_TEP.md`: giải thích bằng lời thường mỗi tệp làm gì.

Không gồm: tests, tài liệu kế hoạch (`docs/`), dữ liệu mô phỏng (`du_lieu_test/`), tệp trình bày/báo cáo.
Mọi số liệu trong ví dụ là dữ liệu MÔ PHỎNG.
